package edu.syr.hw1;

public class Hello {
    public static void main(String[] args){
        // Printing Hello World in main method.
        System.out.println("Hello World");
    }
}